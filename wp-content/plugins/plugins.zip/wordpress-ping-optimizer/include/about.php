<style type="text/css">
	#about{ float: right; width:250px; background: #ffc; border: 1px solid #333; padding: 5px; text-align: justify; }
	#about p, li, ol{ font-family:verdana; font-size:11px; }
	#about h3 {text-align:center;}
	.field_info {text-align:right;};
</style>
<?php echo "<div id='about'> 
	<h3>From the author</h3> 				
	<p>My name is <a href='http://onlinewebapplication.com/about-me/' target='_blank'>Pankaj Jha</a> and I've developed WordPress ping Optimizer. Nice to meet you! :)<p>
	<h3><a href='http://onlinewebapplication.com/wordpress-ping-optimizer/' target='_blank'>WordPress ping Optimizer  </a><h3>
	<h3> <a href='http://onlinewebapplication.com/onlinewebapplication-com-donation/' target='_blank'>Please Donate</a></h3>
</div>"; 
?>
